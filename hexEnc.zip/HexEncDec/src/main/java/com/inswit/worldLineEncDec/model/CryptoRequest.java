package com.inswit.worldLineEncDec.model;

import lombok.Data;

@Data
public class CryptoRequest {

	private String data;
	private String key;
	private String iv;
}