package com.inswit.worldLineEncDec.service;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Hex;
import org.springframework.stereotype.Service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Service
public class EncryptionService {

    private static final Logger log = LogManager.getLogger(EncryptionService.class);

    public String encrypt(String plainText, String key, String iv) {

        long startTime = System.currentTimeMillis();
        log.info("EncryptionService - Encrypt process started");

        try {

            byte[] keyBytes = key.getBytes("UTF-8");
            byte[] ivBytes = iv.getBytes("UTF-8");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

            SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);

            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);

            byte[] encryptedBytes = cipher.doFinal(plainText.getBytes("UTF-8"));

            String encryptedHex = new String(Hex.encodeHex(encryptedBytes));

            log.info("EncryptionService - Encrypted Response : {}", encryptedHex);

            return encryptedHex;

        } catch (Exception ex) {

            log.error("EncryptionService - Encryption Error : ", ex);

            return "Encryption failed : " + ex.getMessage();

        } finally {

            long endTime = System.currentTimeMillis();
            log.info("EncryptionService - Time taken : {} ms", (endTime - startTime));
        }
    }

    public String decrypt(String encryptedHex, String key, String iv) {

        long startTime = System.currentTimeMillis();
        log.info("DecryptionService - Decrypt process started");

        try {

            byte[] keyBytes = key.getBytes("UTF-8");
            byte[] ivBytes = iv.getBytes("UTF-8");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

            SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);

            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);

            byte[] decodedHex = Hex.decodeHex(encryptedHex.toCharArray());

            byte[] decryptedBytes = cipher.doFinal(decodedHex);

            String decryptedText = new String(decryptedBytes, "UTF-8").trim();

            log.info("DecryptionService - Decrypted Response : {}", decryptedText);

            return decryptedText;

        } catch (Exception ex) {

            log.error("DecryptionService - Decryption Error : ", ex);

            return "Decryption failed : " + ex.getMessage();

        } finally {

            long endTime = System.currentTimeMillis();
            log.info("DecryptionService - Time taken : {} ms", (endTime - startTime));
        }
    }
}