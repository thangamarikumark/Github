package com.inswit.worldLineEncDec.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.inswit.worldLineEncDec.model.CryptoRequest;
import com.inswit.worldLineEncDec.service.EncryptionService;

@RestController
@RequestMapping("/hex")
public class EncryptionController {

	private static final Logger log = LogManager.getLogger(EncryptionController.class);

	@Autowired
	EncryptionService encryptionService;

	@PostMapping("/encrypt")
	public String encrypt(@RequestBody CryptoRequest request) {

		log.info("Encryption - Request Received : {}", request.getData());

		try {

			String response = encryptionService.encrypt(request.getData(), request.getKey(), request.getIv());

			log.info("Encryption - Response Received : {}", response);

			return response;

		} catch (Exception ex) {

			log.error("Encryption - Error : ", ex);

			return "Encryption failed : " + ex.getMessage();

		}
	}

	@PostMapping("/decrypt")
	public String decrypt(@RequestBody CryptoRequest request) {

		log.info("Decryption - Request Received : {}", request.getData());

		try {

			String response = encryptionService.decrypt(request.getData(), request.getKey(), request.getIv());

			log.info("Decryption - Response Received : {}", response);

			return response;

		} catch (Exception ex) {

			log.error("Decryption - Error : ", ex);

			return "Decryption failed : " + ex.getMessage();

		}
	}
}